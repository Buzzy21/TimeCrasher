using TMPro;
using UnityEngine;

public class ScoreCounter : MonoBehaviour
{
    public PlayerCollision playerCollision;

    void Update()
    {
        //scoreCount.text = playerCollision.score.ToString();
    }
}
