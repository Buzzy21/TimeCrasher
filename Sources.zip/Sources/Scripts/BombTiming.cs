using UnityEngine;

public class BombTiming : MonoBehaviour
{
    public bool timed;
    void Start()
    {
        timed = false;
    }
}
